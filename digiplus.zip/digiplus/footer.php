<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the .main-content div and #wrapper
 *
 */
?>


	<?php digiplus_get_footer_top_callout(); ?>


	<?php
		/**
		 * digiplus_main_content_end hook.
		 *
		 */
		do_action( 'digiplus_main_content_end' );
	?>
	</div>
	<!-- main-content end -->
	<?php
		/**
		 * digiplus_after_main_content hook.
		 *
		 */
		do_action( 'digiplus_after_main_content' );
	?>


	<?php if( apply_filters('digiplus_filter_show_footer', true) ): ?>
	<?php digiplus_get_footer_parts(); ?>
	<?php endif; ?>

	<?php
		/**
		 * digiplus_wrapper_end hook.
		 *
		 */
		do_action( 'digiplus_wrapper_end' );
	?>
</div>
<!-- wrapper end -->
<?php
	/**
	 * digiplus_body_tag_end hook.
	 *
	 */
	do_action( 'digiplus_body_tag_end' );
?>
<?php
	/**
	 * nav_search_icon_popup_html hook.
	 *
	 */
	do_action( 'digiplus_nav_search_icon_popup_html');
	digiplus_floating_cart_sidebar();
?>
<?php wp_footer(); ?>
</body>
</html>
