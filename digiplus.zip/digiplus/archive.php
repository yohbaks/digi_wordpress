<?php
/**
 * The template for displaying archive pages
 */

get_header();

digiplus_get_title_area_parts();

digiplus_get_blog();

get_footer();
