<?php
if ( mascot_core_digiplus_plugin_installed() ) {
	require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/blog-single/blog-single-metabox.php';
}
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/blog-single/blog-single-css-generators.php';
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/blog-single/blog-single-functions.php';