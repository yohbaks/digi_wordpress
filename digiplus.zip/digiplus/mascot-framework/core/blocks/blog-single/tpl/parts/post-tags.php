
	<?php the_tags( '<ul class="single-post-tags list-inline"><li class="list-inline-item pl--0"><span>' . esc_html__('Tags:', 'digiplus' ) .'</span></li><li class="list-inline-item">', '</li><li class="list-inline-item">', '</li></ul>' ); ?>
