<?php
if ( mascot_core_digiplus_plugin_installed() ) {
	require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/blog/blog-metabox.php';
}
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/blog/blog-css-generators.php';
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/blog/blog-functions.php';