<?php

if (!function_exists('digiplus_sidebar_widget_title_line_bottom_color')) {
	/**
	 * Generate CSS codes for Sidebar Widget Title Custom Line Bottom Color
	 */
	function digiplus_sidebar_widget_title_line_bottom_color() {
		global $digiplus_redux_theme_opt;
		$var_name = 'sidebar-settings-sidebar-title-line-bottom-custom-color';
		//If Make Line Bottom Theme Colored?
		if( $digiplus_redux_theme_opt['sidebar-settings-sidebar-title-line-bottom-theme-colored'] != '' ) {
			return;
		}

		$declaration = array();
		$selector = array(
			'.widget .widget-title.widget-title-line-bottom:after'
		);

		$declaration['background-color'] = $digiplus_redux_theme_opt[$var_name];
		digiplus_dynamic_css_generator($selector, $declaration);
	}
	add_action('digiplus_dynamic_css_generator_action', 'digiplus_sidebar_widget_title_line_bottom_color');
}