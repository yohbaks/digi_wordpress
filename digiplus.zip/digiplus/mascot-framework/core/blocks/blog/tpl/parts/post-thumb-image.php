<div class="post-thumb lightgallery-lightbox">
<?php digiplus_get_blocks_template_part( 'thumb', null, 'blog/tpl/parts', $params ); ?>
</div>