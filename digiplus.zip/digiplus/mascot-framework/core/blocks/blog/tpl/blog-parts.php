<?php
	/**
	* digiplus_before_blog_section hook.
	*
	*/
	do_action( 'digiplus_before_blog_section' );
?>
<section>
	<div class="<?php echo esc_attr( $container_type ); ?>">
		<?php
			/**
			* digiplus_blog_container_start hook.
			*
			*/
			do_action( 'digiplus_blog_container_start' );
		?>

		<div class="blog-posts">
			<?php
				digiplus_get_blog_sidebar_layout();
			?>
		</div>

	<?php
		/**
		* digiplus_blog_container_end hook.
		*
		*/
		do_action( 'digiplus_blog_container_end' );
	?>
	</div>
</section>
<?php
	/**
	* digiplus_after_blog_section hook.
	*
	*/
	do_action( 'digiplus_after_blog_section' );
?>
