<?php
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/footer/footer-css-generators.php';
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/footer/footer-functions.php';