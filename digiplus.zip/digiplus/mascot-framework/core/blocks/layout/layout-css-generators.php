<?php

if (!function_exists('digiplus_layout_settings_boxed_layout_padding_top_bottom')) {
	/**
	 * Generate CSS codes for Boxed Layout - Padding Top & Bottom
	 */
	function digiplus_layout_settings_boxed_layout_padding_top_bottom() {
		global $digiplus_redux_theme_opt;
		$var_name = 'layout-settings-boxed-layout-padding-top-bottom';
		$declaration = array();
		$selector = array(
			'body.tm-boxed-layout',
		);

		//if empty then return
		if( !array_key_exists( $var_name, $digiplus_redux_theme_opt ) ) {
			return;
		}

		//if Page Layout boxed
		if( digiplus_get_redux_option( 'layout-settings-page-layout' ) == 'boxed' ) {
			$padding_top = $digiplus_redux_theme_opt[$var_name]['padding-top'];
			$padding_bottom = $digiplus_redux_theme_opt[$var_name]['padding-bottom'];

			if( !empty( $padding_top ) && $padding_top != "" ) {
				$padding_top = digiplus_remove_suffix( $padding_top, 'px');
				$declaration['padding-top'] = $padding_top . 'px';
			}
			if( !empty( $padding_bottom ) && $padding_bottom != "" ) {
				$padding_bottom = digiplus_remove_suffix( $padding_bottom, 'px');
				$declaration['padding-bottom'] = $padding_bottom . 'px';
			}
		}

		digiplus_dynamic_css_generator($selector, $declaration);
	}
	add_action('digiplus_dynamic_css_generator_action', 'digiplus_layout_settings_boxed_layout_padding_top_bottom');
}


if (!function_exists('digiplus_stretched_layout_background_color')) {
	/**
	 * Generate CSS codes for Stretched Layout - Background Color
	 */
	function digiplus_stretched_layout_background_color() {
		global $digiplus_redux_theme_opt;
		$var_name = 'layout-settings-stretched-layout-bg-bgcolor';
		$declaration = array();
		$selector = array(
			'body.tm-stretched-layout',
		);

		//if empty then return
		if( digiplus_get_redux_option( 'layout-settings-page-layout' ) != 'stretched' ) {
			return;
		}
		if( !array_key_exists( $var_name, $digiplus_redux_theme_opt ) ) {
			return;
		}

		if( digiplus_get_redux_option( 'layout-settings-boxed-layout-bg-type' ) == 'bg-color' ) {
			if( $digiplus_redux_theme_opt[$var_name] != "" ) {
				$declaration['background-color'] = $digiplus_redux_theme_opt[$var_name];
			}
			digiplus_dynamic_css_generator($selector, $declaration);
		}
	}
	add_action('digiplus_dynamic_css_generator_action', 'digiplus_stretched_layout_background_color');
}


if (!function_exists('digiplus_boxed_layout_background_color')) {
	/**
	 * Generate CSS codes for Boxed Layout - Background Color
	 */
	function digiplus_boxed_layout_background_color() {
		global $digiplus_redux_theme_opt;
		$var_name = 'layout-settings-boxed-layout-bg-type-bgcolor';
		$declaration = array();
		$selector = array(
			'body.tm-boxed-layout',
		);

		//if empty then return
		if( !array_key_exists( $var_name, $digiplus_redux_theme_opt ) ) {
			return;
		}

		if( digiplus_get_redux_option( 'layout-settings-boxed-layout-bg-type' ) == 'bg-color' ) {
			if( $digiplus_redux_theme_opt[$var_name] != "" ) {
				$declaration['background-color'] = $digiplus_redux_theme_opt[$var_name];
			}
			digiplus_dynamic_css_generator($selector, $declaration);
		}
	}
	add_action('digiplus_dynamic_css_generator_action', 'digiplus_boxed_layout_background_color');
}




if (!function_exists('digiplus_boxed_layout_background_pattern')) {
	/**
	 * Generate CSS codes for Boxed Layout - Background Pattern
	 */
	function digiplus_boxed_layout_background_pattern() {
		global $digiplus_redux_theme_opt;
		$var_name = 'layout-settings-boxed-layout-bg-type-pattern';
		$declaration = array();
		$selector = array(
			'body.tm-boxed-layout',
		);

		//if empty then return
		if( !array_key_exists( $var_name, $digiplus_redux_theme_opt ) ) {
			return;
		}

		if( digiplus_get_redux_option( 'layout-settings-boxed-layout-bg-type' ) == 'bg-patter' ) {
			if( $digiplus_redux_theme_opt[$var_name] != "" ) {
				$declaration['background-image'] = 'url('.$digiplus_redux_theme_opt[$var_name].')';
			}
			digiplus_dynamic_css_generator($selector, $declaration);
		}
	}
	add_action('digiplus_dynamic_css_generator_action', 'digiplus_boxed_layout_background_pattern');
}


if (!function_exists('digiplus_boxed_layout_bg')) {
	/**
	 * Generate CSS codes for Widget Footer Background
	 */
	function digiplus_boxed_layout_bg() {
		global $digiplus_redux_theme_opt;
		$var_name = 'layout-settings-boxed-layout-bg-type-bgimg';
		$declaration = array();
		$selector = array(
			'body.tm-boxed-layout',
		);

		//if empty then return
		if( !array_key_exists( $var_name, $digiplus_redux_theme_opt ) ) {
			return;
		}

		if( digiplus_get_redux_option( 'layout-settings-boxed-layout-bg-type' ) == 'bg-image' ) {
			$declaration = digiplus_redux_option_field_background( $var_name );
			digiplus_dynamic_css_generator($selector, $declaration);
		}
	}
	add_action('digiplus_dynamic_css_generator_action', 'digiplus_boxed_layout_bg');
}





if (!function_exists('digiplus_dark_layout_background_color')) {
	/**
	 * Generate CSS codes for dark Layout - Background Color
	 */
	function digiplus_dark_layout_background_color() {
		global $digiplus_redux_theme_opt;
		$var_name = 'general-settings-dark-mode-custom-bgcolor';
		$declaration = array();
		$selector = array(
			'[data-tm-layout="dark"]'
		);

		//if empty then return
		if( digiplus_get_redux_option( 'general-settings-enable-dark-mode' ) != '1' ) {
			return;
		}

		if( $digiplus_redux_theme_opt[$var_name] != "" ) {
			$declaration['--body-bg'] = $digiplus_redux_theme_opt[$var_name] . '!important';
			digiplus_dynamic_css_generator($selector, $declaration);
		}
	}
	add_action('digiplus_dynamic_css_generator_action', 'digiplus_dark_layout_background_color');
}