<?php
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/layout/layout-css-generators.php';
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/layout/layout-functions.php';