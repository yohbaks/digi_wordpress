<?php
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/footer-top-callout/footer-top-callout-css-generators.php';
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/footer-top-callout/footer-top-callout-functions.php';