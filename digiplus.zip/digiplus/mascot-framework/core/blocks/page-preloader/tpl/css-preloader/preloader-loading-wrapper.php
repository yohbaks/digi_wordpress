<div class="preloader-loading-wrapper">
  <div class="cssload-loading"><i></i><i></i></div>
</div>