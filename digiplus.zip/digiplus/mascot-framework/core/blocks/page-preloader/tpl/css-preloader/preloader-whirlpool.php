<div class="preloader-whirlpool">
  <div class="whirlpool"></div>
</div>