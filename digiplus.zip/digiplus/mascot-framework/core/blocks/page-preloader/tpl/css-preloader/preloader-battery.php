
<div class="preloader-battery">
  <div class="cssload-liquid"></div>
</div>