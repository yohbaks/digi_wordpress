<div class="preloader-jackhammer">
  <ul class="cssload-flex-container">
	<li>
		<span class="cssload-loading"></span>
	</li>
  </ul>
</div>