<div class="preloader-square-swapping">
  <div class="cssload-square-part cssload-square-green"></div>
  <div class="cssload-square-part cssload-square-pink"></div>
  <div class="cssload-square-blend"></div>
</div>