<?php

require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/page-preloader/page-preloader-css-generators.php';
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/page-preloader/page-preloader-functions.php';