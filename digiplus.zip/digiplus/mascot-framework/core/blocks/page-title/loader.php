<?php
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/page-title/page-title-css-generators.php';
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/page-title/page-title-functions.php';