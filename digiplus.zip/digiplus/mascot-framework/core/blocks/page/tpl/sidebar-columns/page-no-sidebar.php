<div class="row tm-blog-sidebar-row">
	<div class="col-lg-12">
		<div class="main-content-area">
			<?php do_action( 'digiplus_page_main_content_area_start' ); ?>
			<?php
				digiplus_get_page_content();
			?>
			<?php do_action( 'digiplus_page_main_content_area_end' ); ?>
		</div>
	</div>
</div>