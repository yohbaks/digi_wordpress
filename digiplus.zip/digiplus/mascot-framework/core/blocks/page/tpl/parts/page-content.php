<div id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="entry-content">
		<div class="page-content">
			<?php
				digiplus_get_blog_single_post_thumbnail();
			?>
			<?php
				/**
				* digiplus_before_page_content hook.
				*
				*/
				do_action( 'digiplus_before_page_content' );
			?>
			<?php
				the_content();
			?>
			<?php
				/**
				* digiplus_after_page_content hook.
				*
				*/
				do_action( 'digiplus_after_page_content' );
			?>

			<?php digiplus_get_post_wp_link_pages(); ?>

			<?php
				if( digiplus_get_redux_option( 'page-settings-show-share' ) ) {
					digiplus_get_social_share_links();
				}
			?>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<?php
	if( $page_show_comments ) {
		digiplus_show_comments();
	}
?>
