<?php
if ( mascot_core_digiplus_plugin_installed() ) {
	require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/page/page-metabox.php';
}
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/page/page-css-generators.php';
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/page/page-functions.php';