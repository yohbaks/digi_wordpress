<?php

require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/404/404-css-generators.php';
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/404/404-functions.php';