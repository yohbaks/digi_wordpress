<?php

require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/maintenance-mode/maintenance-mode-css-generators.php';
