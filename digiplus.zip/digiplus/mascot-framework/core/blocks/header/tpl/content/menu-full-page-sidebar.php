<div class="menufullpage-nav-sidebar">
	<div class="menufullpage-nav-sidebar-inner">
		<?php if ( is_active_sidebar( 'header-menufullpage-nav-sidebar' ) ) : ?>
			<?php dynamic_sidebar( 'header-menufullpage-nav-sidebar' ); ?>
		<?php endif; ?>
	</div>
</div>