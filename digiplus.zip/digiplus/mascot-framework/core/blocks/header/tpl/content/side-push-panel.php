<div class="<?php echo esc_attr( $hidden_class ); ?>">
	<div class="side-panel-trigger" data-target="<?php echo esc_attr($holder_id)?>">
		<a href="#">
			<div class="hamburger-box">
				<div class="hamburger-inner"></div>
			</div>
		</a>
	</div>
</div>