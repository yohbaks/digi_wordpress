
	<?php
	/**
	* digiplus_before_top_sliders_container hook.
	*
	*/
	do_action( 'digiplus_before_top_sliders_container' );
	?>
	<div class="top-sliders-container">
		<?php
			/**
			* digiplus_top_sliders_container_start hook.
			*
			*/
			do_action( 'digiplus_top_sliders_container_start' );
		?>

		<?php
			echo digiplus_get_top_main_slider();
		?>

		<?php
			/**
			* digiplus_top_sliders_container_end hook.
			*
			*/
			do_action( 'digiplus_top_sliders_container_end' );
		?>
	</div>
	<?php
	/**
	* digiplus_after_top_sliders_container hook.
	*
	*/
	do_action( 'digiplus_after_top_sliders_container' );
	?>
