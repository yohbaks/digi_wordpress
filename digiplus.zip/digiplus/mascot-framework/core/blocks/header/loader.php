<?php
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/header/header-css-generators.php';
require_once DIGIPLUS_FRAMEWORK_DIR . '/core/blocks/header/header-functions.php';