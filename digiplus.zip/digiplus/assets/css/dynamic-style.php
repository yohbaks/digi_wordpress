<?php

// Dynamically generated css code goes here:
do_action('digiplus_dynamic_css_generator_action');